package com.example.hm3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);






        setContentView(R.layout.activity_main);
        Button conbtn = (Button) findViewById(R.id.conbtn);
        Button appbtn = (Button) findViewById(R.id.appbtn);
        Button abotbtn = (Button) findViewById(R.id.aboubtn);


        conbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent con = new Intent(MainActivity.this , ContactUs.class);
                startActivity(con);
            }
        });

        appbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent app = new Intent(MainActivity.this , Apply.class);
                startActivity(app);
            }
        });

        abotbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent abot = new Intent(MainActivity.this ,AboutUs.class );
                startActivity(abot);
            }
        });
    }


}