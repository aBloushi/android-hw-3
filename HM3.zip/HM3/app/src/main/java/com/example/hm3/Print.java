package com.example.hm3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Print extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_print);


        TextView Major = (TextView) findViewById(R.id.YourMajor);


        final Button correct = (Button) findViewById(R.id.button5);
        final Button restart = (Button) findViewById(R.id.button4);


      final  TextView Ename = (TextView) findViewById(R.id.name);
      final  TextView Eage = (TextView) findViewById(R.id.age);
      final  TextView Eemail = (TextView) findViewById(R.id.email);
      final  TextView Enumber = (TextView) findViewById(R.id.number);


    final   String x = "1";


        Bundle Majors = getIntent().getExtras();

        String Choice = Majors.getString("Major");
        String name = Majors.getString("name");
        String age = Majors.getString("age");
        String email = Majors.getString("email");
        String number = Majors.getString("number");

        Major.setText(Choice);


        Ename.setText(name);
        Eage.setText(age);
        Eemail.setText(email);
        Enumber.setText(number);


        correct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent dialoge = new Intent(Print.this ,MainActivity.class);
                Toast.makeText(Print.this, "Success! we will get back to you shortly", Toast.LENGTH_SHORT).show();
                startActivity(dialoge);
            }
        });
        restart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent re = new Intent(Print.this ,MainActivity.class);
                startActivity(re);
            }
        });

    }
}