package com.example.hm3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Apply extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_apply);


        final TextView Physics = (TextView) findViewById(R.id.Physics);
        final TextView Neuroscience = (TextView) findViewById(R.id.Neuroscience);
        final TextView Microbiology = (TextView) findViewById(R.id.Microbiology);
        final TextView Mathematical = (TextView) findViewById(R.id.Mathematical);
        final TextView Mechanical = (TextView) findViewById(R.id.Mechanical);
        final TextView Chemical = (TextView) findViewById(R.id.Chemical);
        final TextView Biochemistry = (TextView) findViewById(R.id.Biochemistry);
        final TextView Bio = (TextView) findViewById(R.id.Bio);
        final TextView Medicine = (TextView) findViewById(R.id.Medicine);

        Physics.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
             String x =Physics.getText().toString();
                Intent Move = new Intent(Apply.this , Major.class);
              Move.putExtra("Major",x);
              startActivity(Move);
            }
        });

        Neuroscience.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String x =Neuroscience.getText().toString();
                Intent Move = new Intent(Apply.this , Major.class);
                Move.putExtra("Major" , x);
                startActivity(Move);
            }
        });

        Microbiology.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String x =Microbiology.getText().toString();
                Intent Move = new Intent(Apply.this , Major.class);
                Move.putExtra("Major" , x);
                startActivity(Move);
            }
        });

        Mathematical.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String x =Mathematical.getText().toString();
                Intent Move = new Intent(Apply.this , Major.class);
                Move.putExtra("Major" , x);
                startActivity(Move);
            }
        });

        Mechanical.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String x =Mechanical.getText().toString();
                Intent Move = new Intent(Apply.this , Major.class);
                Move.putExtra("Major" , x);
                startActivity(Move);
            }
        });

        Chemical.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String x =Chemical.getText().toString();
                Intent Move = new Intent(Apply.this , Major.class);
                Move.putExtra("Major" , x);
                startActivity(Move);
            }
        });

        Biochemistry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String x =Biochemistry.getText().toString();
                Intent Move = new Intent(Apply.this , Major.class);
                Move.putExtra("Major" , x);
                startActivity(Move);
            }
        });

        Bio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String x =Bio.getText().toString();
                Intent Move = new Intent(Apply.this , Major.class);
                Move.putExtra("Major" , x);
                startActivity(Move);
            }
        });

        Medicine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String x =Medicine.getText().toString();
                Intent Move = new Intent(Apply.this , Major.class);
                Move.putExtra("Major" , x);
                startActivity(Move);
            }
        });
    }

}