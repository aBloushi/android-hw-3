package com.example.hm3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class ContactUs extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_us);
        ImageView mapbtn = (ImageView) findViewById(R.id.imageView2);


        mapbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("https://www.google.com/maps/place/Harvard+University/@42.3770068,-71.1188488,17z/data=!3m1!4b1!4m5!3m4!1s0x89e377427d7f0199:0x5937c65cee2427f0!8m2!3d42.3770029!4d-71.1166601"));

                startActivity(intent);
            }
        });
    }
}